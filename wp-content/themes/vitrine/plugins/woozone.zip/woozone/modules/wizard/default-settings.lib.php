<?php 
// die here